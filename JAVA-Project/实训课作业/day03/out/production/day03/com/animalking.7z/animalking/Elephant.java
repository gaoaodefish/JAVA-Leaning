package com.animalking;

public class Elephant extends Mammal{
    public Elephant (String name){
        super(name);
    }

    @Override
    public void makeSound() {
        System.out.println(name+"叫声：hang hang!");
    }

    public void eat(String food){
        System.out.println(name+"eat: "+food);
    }

    public void move(){
        System.out.println(name+"移动方式：running");
    }
}
