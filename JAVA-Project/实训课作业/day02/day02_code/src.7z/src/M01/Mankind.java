package M01;

public class Mankind {
    public String name;
    public int id;

    public void setData(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public void print() {
        System.out.println(name + ", " + id);
    }
}


