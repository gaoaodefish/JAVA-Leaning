package S01;

import M01.Mankind;

public class Student extends Mankind {
    public String sit;
    public String exp;
    public void print(){
        System.out.println("学生：");
        super.print();
    }
}
